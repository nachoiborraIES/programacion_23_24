﻿/*
 * Clase principal proyecto LigaBasket.
 */

class Program
{
    private const string EQUIPOS = "Equipos.txt";
    private const string PARTIDOS = "Partidos.txt";
    static void Main(string[] args)
    {
        List<Equipo> equipos = CargarEquipos();
        List<Partido> partidos = CargarPartidos(equipos);
        AnyadirPartidos(equipos, partidos);
        foreach (Partido partido in partidos)
        {
            ActualizarClasificacion(partido.EquipoLocal, partido.PuntosLocal,
                partido.EquipoVisitante, partido.PuntosVisitante);
        }
        MostrarClasificacion(equipos);
        Guardar(equipos, partidos);
    }

    static void AnyadirPartidos(List<Equipo> equipos,
        List<Partido> partidos)
    {
        bool fin = false;
        Console.WriteLine("Introduce el partido con los dos equipos y " +
                    "sus resultados en una única línea: ");
        do
        {
            Console.WriteLine("Pulse enter para NO añadir ningún partido");
            string lineaPartido = Console.ReadLine();
            if (lineaPartido != "")
            {
                string[] datos = lineaPartido.Split(';');
                if (datos.Length == 4)
                {
                    Equipo equipoLocal = BuscarEquipo(equipos, datos[0]);
                    Equipo equipoVisitante = BuscarEquipo(equipos, datos[2]);
                    if (equipoLocal == null || equipoVisitante == null)
                    {
                        Console.WriteLine("Uno o ambos equipos no existen.");
                    }
                    else
                    {
                        if (!int.TryParse(datos[1], out int puntosLocal) || 
                            !int.TryParse(datos[3], out int puntosVisitante) ||
                            puntosLocal < 0 || puntosLocal > 200 || 
                            puntosVisitante < 0 || puntosVisitante > 200)
                        {
                            Console.WriteLine("Los puntos deben ser números " +
                                "válidos y comprendidos entre 0 y 200.");
                        }
                        else
                        {
                            partidos.Add(new Partido(equipoLocal, 
                                int.Parse(datos[1]), equipoVisitante, 
                                int.Parse(datos[3])));
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Error en el formato del partido");
                }
            }
            else
            {
                fin = true;
            }

        } while (!fin);
    }

    static List<Equipo> CargarEquipos()
    {
        List<Equipo> equipo = null;
        equipo = new List<Equipo>();
        string[] lineas = File.ReadAllLines(EQUIPOS);
        foreach (string linea in lineas)
        {
            equipo.Add(new Equipo(linea));
        }
        return equipo;
    }

    static List<Partido> CargarPartidos(List<Equipo> equipos)
    {
        List<Partido> partidos = null;
        partidos = new List<Partido>();
        string[] lineas = File.ReadAllLines(PARTIDOS);
        foreach (string linea in lineas)
        {
            string[] datos = linea.Split(';');
            Equipo equipoLocal = BuscarEquipo(equipos, datos[0]);
            Equipo equipoVisitante = BuscarEquipo(equipos, datos[2]);
            if (equipoLocal != null && equipoVisitante != null)
            {
                partidos.Add(new Partido(equipoLocal, int.Parse(datos[1]),
                    equipoVisitante, int.Parse(datos[3])));
            }
        }
        return partidos;
    }

    static Equipo BuscarEquipo(List<Equipo> equipos, string nombre)
    {
        Equipo buscarEquipo = null;
        foreach (Equipo equipo in equipos)
        {
            if (equipo.Nombre == nombre)
            {
                buscarEquipo = equipo;
            }
        }
        return buscarEquipo;
    }

    static void ActualizarClasificacion(Equipo equipoLocal, int puntosLocal,
        Equipo equipoVisitante, int puntosVisitante)
    {
        equipoLocal.ActualizarPuntos(puntosLocal, puntosVisitante);
        equipoVisitante.ActualizarPuntos(puntosVisitante, puntosLocal);
    }

    static void MostrarClasificacion(List<Equipo> equipos)
    {
        equipos.Sort((equipo1, equipo2) =>
        {
            int comparacion = equipo2.PartidosGanados.
            CompareTo(equipo1.PartidosGanados);
            if (comparacion == 0)
            {
                comparacion = (equipo2.PuntosAFavor - equipo2.PuntosEnContra).
                CompareTo(equipo1.PuntosAFavor - equipo1.PuntosEnContra);
                if (comparacion == 0)
                {
                    comparacion = equipo2.PuntosAFavor.
                    CompareTo(equipo1.PuntosAFavor);
                }
            }
            return comparacion;
        });
        
        Console.WriteLine("Clasificación:");
        string cabecera = "Equipo" + new string(' ', 14) + "PG" + 
            new string(' ', 4) + "PP" + new string(' ', 4) + "PF" + 
            new string(' ', 5) + "PC";
        Console.WriteLine();
        Console.WriteLine(cabecera);
        foreach (Equipo equipo in equipos)
        {
            Console.WriteLine(equipo.ToString());
        }
    }

    static void Guardar(List<Equipo> equipos, List<Partido> partidos)
    {
        using (StreamWriter escritor = new StreamWriter(EQUIPOS))
        {
            foreach (Equipo equipo in equipos)
            {
                escritor.WriteLine(equipo.Nombre);
            }
        }
        using (StreamWriter escritor = new StreamWriter(PARTIDOS))
        {
            foreach (Partido partido in partidos)
            {
                escritor.WriteLine(partido.ToFile());
            }
        }
        Console.WriteLine();
        Console.WriteLine("Equipos guardados en el archivo: " + EQUIPOS);
        Console.WriteLine("Partidos guardados en el archivo: " + PARTIDOS);
        Console.WriteLine();
    }
}