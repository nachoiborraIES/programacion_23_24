﻿/*
 * Clase equipo para almacenar los datos de cada equipo.
 */

class Equipo
{
    private string nombre;
    private int partidosGanados;
    private int partidosPerdidos;
    private int puntosFavor;
    private int puntosContra;

    public Equipo(string nombre)
    {
        this.nombre = nombre;
        this.partidosGanados = 0;
        this.partidosPerdidos = 0;
        this.puntosFavor = 0;
        this.puntosContra = 0;
    }

    public string Nombre
    {
        get { return nombre; }
    }

    public int PartidosGanados
    {
        get { return partidosGanados; }
    }

    public int PuntosAFavor
    {
        get { return puntosFavor; }
    }

    public int PuntosEnContra
    {
        get { return puntosContra; }
    }


    public void ActualizarPuntos(int puntosFavor, int puntosContra)
    {
        this.puntosFavor += puntosFavor;
        this.puntosContra += puntosContra;
        if (puntosFavor > puntosContra)
        {
            partidosGanados++;
        }
        else
        {
            partidosPerdidos++;
        }
    }

    public string ToString()
    {
        return nombre + new string(' ',20 - nombre.Length) + partidosGanados + 
            new string(' ', 5) + partidosPerdidos + new string(' ', 5) +
            puntosFavor + new string(' ', 5) + puntosContra;
    }
}

