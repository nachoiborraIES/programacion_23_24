﻿/*
 * Clase partido para almacenar los datos de cada partido.
 */

class Partido
{
    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private int puntosLocal;
    private int puntosVisitante;

    public Partido(Equipo equipoLocal, int puntosLocal, Equipo equipoVisitante,
        int puntosVisitante)
    {
        this.equipoLocal = equipoLocal;
        this.puntosLocal = puntosLocal;
        this.equipoVisitante = equipoVisitante;
        this.puntosVisitante = puntosVisitante;
    }

    public Equipo EquipoLocal
    {
        get { return equipoLocal; }
    }

    public Equipo EquipoVisitante
    {
        get { return equipoVisitante; }
    }

    public int PuntosLocal
    {
        get { return puntosLocal; }
    }

    public int PuntosVisitante
    {
        get { return puntosVisitante; }
    }

    

    public override string ToString()
    {
        return equipoLocal.Nombre + " " + puntosLocal + " - " + 
            equipoVisitante.Nombre + " " + puntosVisitante;
    }

    public string ToFile()
    {
        return equipoLocal.Nombre + ";" + puntosLocal + ";" + 
            equipoVisitante.Nombre + ";" + puntosVisitante;
    }

}

