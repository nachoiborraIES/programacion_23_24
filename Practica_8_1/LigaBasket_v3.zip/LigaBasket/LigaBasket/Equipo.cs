﻿//Clase equipo que contiene los datos respectivos de cada equipo
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Equipo
{
    private string nombre;
    private int partidosGanados;
    private int partidosPerdidos;
    private int puntosFavor;
    private int puntosContra;

    public Equipo(string nombre)
    {
        this.nombre = nombre;
        partidosGanados = 0;
        partidosPerdidos = 0;
        puntosFavor = 0;
        puntosContra = 0;
    }
    public string GetNombre()
    {
        return nombre;
    }
    public int GetPartidosGanados()
    {
        return partidosGanados;
    }
    public int GetPartidosPerdidos()
    {
        return partidosPerdidos;
    }
    public int GetPuntosFavor()
    {
        return puntosFavor;
    }
    public int GetPuntosContra()
    {
        return puntosContra;
    }
    public void SetNombre(string nombre)
    {
        this.nombre = nombre;
    }
    public void PartidoGanado()
    {
        partidosGanados++;
    }
    public void PartidoPerdido()
    {
        partidosPerdidos++;
    }
    public void PuntoAFavor(int puntosFavor)
    {
        this.puntosFavor += puntosFavor;
    }
    public void PuntoEnContra(int puntosContra)
    {
        this.puntosContra += puntosContra;
    }
    public override string ToString()
    {
        return nombre + new string(' ',21-nombre.Length) + partidosGanados + 
            new string(' ', 15-partidosGanados.ToString().Length) + 
            partidosPerdidos + new string(' ',16-partidosPerdidos.ToString().
            Length) + puntosFavor + new string(' ',20-puntosFavor.ToString().
            Length) + puntosContra;
    }
}
