﻿/*Clase Main en la que llevaremos a cabo las funcionalidades principales del 
 * programa.*/
using System.Reflection.Metadata.Ecma335;

class Program
{
    static void Main(string[] args)
    {
        List<Equipo> equipos = CrearEquipos();
        List<Partido> partidos = CrearPartidos(equipos);
        AddPartidos(equipos, partidos);
        MostrarEquipos(equipos);
        GuardarPartidos(partidos);
    }
    static List<Equipo> CrearEquipos()
    {
        List<Equipo> equipos = new List<Equipo>();
        if (File.Exists("Equipos.txt"))
        {
            string linea;
            using (StreamReader fichero = new StreamReader("Equipos.txt"))
            {
                while ((linea = fichero.ReadLine()) != null)
                {
                    equipos.Add(new Equipo(linea));
                }
            }
        }
        return equipos;
    }
    static List<Partido> CrearPartidos(List<Equipo> equipos)
    {
        List<Partido> partidos = new List<Partido>();
        if (File.Exists("Partidos.txt"))
        {
            string linea;
            string[] partes;
            using(StreamReader fichero = new StreamReader("Partidos.txt"))
            {
                while((linea = fichero.ReadLine()) != null)
                {
                    partes = linea.Split(";");
                    Equipo equipo1 = EncontrarEquipo(equipos, partes[0]);
                    int puntosEquipo1 = Convert.ToInt32(partes[1]);
                    Equipo equipo2 = EncontrarEquipo(equipos, partes[2]);
                    int puntosEquipo2 = Convert.ToInt32(partes[3]);
                    partidos.Add(new Partido(equipo1,puntosEquipo1,equipo2,
                        puntosEquipo2));
                    partidos.Last().ProcesarPartido();
                }
            }
        }
        return partidos;
    }
    static Equipo EncontrarEquipo(List<Equipo> equipos, string nombre)
    {
        Equipo equipo = null;
        for(int i = 0; i < equipos.Count; i++)
        {
            if(nombre == equipos[i].GetNombre())
            {
                equipo = equipos[i];
            }
        }
        return equipo;
    }
    static void AddPartidos(List<Equipo>equipos, List<Partido> partidos)
    {
        string partido;
        do
        {
            Console.WriteLine("Introduce el nuevo partido: ");
            partido = Console.ReadLine();
            if(partido != "")
            {
                string[] partes = ComprobarFormato(partido);
                if (partes != null)
                {
                    Equipo equipo1 = EncontrarEquipo(equipos, partes[0]);
                    Equipo equipo2 = EncontrarEquipo(equipos, partes[2]);
                    int puntosEquipo1 = Convert.ToInt32(partes[1]);
                    int puntosEquipo2 = Convert.ToInt32(partes[3]);
                    if(equipo1 != null && equipo2 != null)
                    {
                        partidos.Add(new Partido(equipo1,puntosEquipo1,equipo2,
                            puntosEquipo2));
                        Console.WriteLine("Partido añadido.");
                        partidos.Last().ProcesarPartido();
                    }
                    else
                    {
                        Console.WriteLine("Alguno o ambos equipos no existen."
                            + "Vuelva a comenzar.");
                    }
                }
            }
        }
        while (partido != "");
    }
    static string[] ComprobarFormato(string partido)
    {
        string[] partes = partido.Split(";");
        if(partes.Length == 4)
        {
            try
            {
                int puntosEquipo1 = Convert.ToInt32(partes[1]);
                int puntosEquipo2 = Convert.ToInt32(partes[3]);
                if(puntosEquipo1 < 0 || puntosEquipo1 > 200 || 
                    puntosEquipo2 < 0 || puntosEquipo2 > 200)
                {
                    Console.WriteLine("Puntuaciones no válidas. " + 
                        "Vuelva a comenzar.");
                    partes = null;
                }
            }
            catch
            {
                Console.WriteLine("Puntuaciones no válidas. " +
                        "Vuelva a comenzar.");
                partes = null;
            }
        }
        else
        {
            Console.WriteLine("Formato incorrecto. Vuelva a comenzar.");
            partes = null;
        }
        return partes;
    }
    static void MostrarEquipos(List<Equipo> equipos)
    {
        equipos.Sort(new OrdenadorEquipos());
        Console.WriteLine("Nombre equipo        ganados        perdidos" + 
            "        puntos_favor        puntos_contra");
        for(int i = 0; i < equipos.Count; i++)
        {
            Console.WriteLine(equipos[i]);
        }
    }
    static void GuardarPartidos(List<Partido> partidos)
    {
        using(StreamWriter fichero = new StreamWriter("Partidos.txt"))
        {
            for(int i = 0; i < partidos.Count; i++)
            {
                fichero.WriteLine(partidos[i].ToFile());
            }
        }
    }
}