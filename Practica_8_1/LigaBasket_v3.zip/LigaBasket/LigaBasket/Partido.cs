﻿/*Clase partido en la que almacenamos todos los datos sobre los partidos entre
 los diferentes equipos.*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Partido
{
    private Equipo equipo1;
    private Equipo equipo2;
    private int puntosEquipo1;
    private int puntosEquipo2;

    public Partido(Equipo equipo1, int puntosEquipo1, Equipo equipo2, 
        int puntosEquipo2)
    {
        this.equipo1 = equipo1;
        this.puntosEquipo1 = puntosEquipo1;
        this.equipo2 = equipo2;
        this.puntosEquipo2 = puntosEquipo2;
    }
    public void ProcesarPartido()
    {
        if(puntosEquipo1 > puntosEquipo2)
        {
            equipo1.PartidoGanado();
            equipo2.PartidoPerdido();
        }
        else if(puntosEquipo2 > puntosEquipo1)
        {
            equipo2.PartidoGanado();
            equipo1.PartidoPerdido();
        }
        equipo1.PuntoAFavor(puntosEquipo1);
        equipo1.PuntoEnContra(puntosEquipo2);
        equipo2.PuntoAFavor(puntosEquipo2);
        equipo2.PuntoEnContra(puntosEquipo1);
    }
    public string ToFile()
    {
        return equipo1.GetNombre() + ";" + puntosEquipo1 + ";" + equipo2.
            GetNombre() + ";" + puntosEquipo2;
    }
}
