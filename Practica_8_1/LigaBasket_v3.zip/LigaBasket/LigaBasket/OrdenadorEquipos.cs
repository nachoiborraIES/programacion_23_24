﻿//Clase para ordenar los equipos por los criterios establecidos
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class OrdenadorEquipos : IComparer<Equipo>
{
    public int Compare(Equipo e1, Equipo e2)
    {
        int ordenacion;
        ordenacion = e2.GetPartidosGanados().CompareTo(e1.
            GetPartidosGanados());
        if(ordenacion == 0)
        {
            ordenacion = (e2.GetPuntosFavor() - e2.GetPuntosContra()).
                CompareTo(e1.GetPuntosFavor() - e1.GetPuntosContra());
            if (ordenacion == 0)
            {
                ordenacion = e2.GetPuntosFavor().CompareTo(
                    e1.GetPuntosFavor());
            }
        }
        return ordenacion;
    }
}
