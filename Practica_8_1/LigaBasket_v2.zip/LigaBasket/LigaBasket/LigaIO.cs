﻿/*
 * Clase abstracta dedicada a las funciones de guardado y cargado
 * de ficheros
 */
abstract class LigaIO
{
    const string FICHERO_EQUIPOS = "Equipos.txt";
    const string FICHERO_PARTIDOS = "Partidos.txt";
    public static List<Equipo> cargarEquipos()
    {
        List<Equipo> equipos = new List<Equipo>(); 
        string nombreEquipo;

        using (StreamReader fichero = new StreamReader(FICHERO_EQUIPOS))
        {
            do
            {
                nombreEquipo = fichero.ReadLine();
                if (nombreEquipo != null)
                {
                    equipos.Add(new Equipo(nombreEquipo));
                }
            }
            while (nombreEquipo != null);
        }

        return equipos;
    }

    public static List<Partido> cargarPartidos()
    {
        List<Partido> partidos = new List<Partido>();
        string partido;

        using (StreamReader fichero = new StreamReader(FICHERO_PARTIDOS))
        {
            do
            {
                partido = fichero.ReadLine();
                if (partido != null)
                {
                    string[] partidoSplit = partido.Split(";");
                    Equipo local = new Equipo(partidoSplit[0]);
                    Equipo visitante = new Equipo(partidoSplit[2]);
                    int puntosLocal = Convert.ToInt32(partidoSplit[1]);
                    int puntosVisitante = Convert.ToInt32(partidoSplit[3]);
                    partidos.Add(new Partido(local, visitante,
                        puntosLocal, puntosVisitante ));
                }
            }
            while (partido != null);
        }
        return partidos;
    }

    public static void GuardarPartidos(List<Partido> partidos)
    {
        using(StreamWriter fichero = new StreamWriter(FICHERO_PARTIDOS))
        {
            foreach(Partido partido in partidos)
            {
                fichero.WriteLine(partido.GuardarEnFichero());
            }
        }
    }
}

