﻿/*
 * Clase preparada para gesitionar la información de los partidos 
 */
class Partido
{
    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private int puntosLocal;
    private int puntosVisitante;

    public Partido(Equipo equipoLocal, Equipo equipoVisitante,
        int puntosLocal, int puntosVisitante)
    {
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.puntosLocal = puntosLocal;
        this.puntosVisitante = puntosVisitante;
    }

    public Equipo EquipoLocal
    {
        get { return equipoLocal; }
    }

    public Equipo EquipoVisitante
    {
        get { return equipoVisitante; }
    }
    public int PuntosLocal
    {
        get { return puntosLocal; }
    }
    public int PuntosVisitante
    {
        get { return puntosVisitante; }
    }

    public string GuardarEnFichero()
    {
        return equipoLocal.Nombre+";"+puntosLocal+";"
            +equipoVisitante.Nombre+";"+puntosVisitante;
    }
    public override string ToString()
    {
        return EquipoLocal + " puntos: " + puntosLocal +
            " - " + EquipoVisitante + " puntos: " + puntosVisitante + "\n";
    }
}


