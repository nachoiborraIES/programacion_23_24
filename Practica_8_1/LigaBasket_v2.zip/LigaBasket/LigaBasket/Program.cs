﻿/*
 * Clase principal que contiene el main y los métodos principales 
 * para gestionar el programa
 */
class Program
{
    static void Main(string[] args)
    {
        List<Partido> partidos = LigaIO.cargarPartidos();
        List<Equipo> equipos = LigaIO.cargarEquipos();
        NuevoPartido(partidos, equipos);
        ProcesarPartidos(partidos, equipos);
        MostrarTabla(equipos);
        LigaIO.GuardarPartidos(partidos);
    }
    static void MostrarTabla(List<Equipo> equipos)
    {
        int y = 0;
        Console.Clear();
        equipos.Sort();
        foreach(Equipo e in equipos)
        {
            e.MostrarEquipos(y);
            y++;
        }
        Console.WriteLine();
    }

    static void NuevoPartido(List<Partido> partidos, List<Equipo> equipos)
    {
        int puntosLocal, puntosVisitante;
        int indiceLocal, indiceVisitante;
        string partido;
        bool correcto = false;
        do
        {
            correcto = false;
            Console.WriteLine();
            Console.WriteLine("Escribe un nuevo partido: ");
            partido = Console.ReadLine();
            if (partido != "")
            {
                string[] partidoSplit = partido.Split(";");
                if (partidoSplit.Length == 4 
                    && int.TryParse(partidoSplit[1], out puntosLocal)
                    && int.TryParse(partidoSplit[3], out puntosVisitante))
                {
                    if (puntosLocal >= 0 && puntosLocal <= 200 &&
                        puntosVisitante >= 0 && puntosVisitante <= 200)
                    {
                        Equipo local = new Equipo(partidoSplit[0]);
                        Equipo visitante = new Equipo(partidoSplit[2]);
                        EncontrarEquipos(equipos, local, visitante,
                            out indiceLocal, out indiceVisitante);
                        if (indiceVisitante != -1 && indiceLocal != -1)
                        {
                            correcto = true;
                            partidos.Add(new Partido(local, visitante,
                                puntosLocal, puntosVisitante));
                        }
                        else
                            Console.WriteLine("Algun equipo no existe...");
                    }
                    else
                        Console.WriteLine("Puntos no válidos.");
                }
                else
                    Console.WriteLine("Error de formato");
                
                if (correcto)
                    Console.WriteLine("Partido introducido correctamente.");
                else
                    Console.WriteLine("Error al introducir partido...");
            }
        }
        while (partido != "");
        ProcesarPartidos(partidos, equipos);
        MostrarTabla(equipos);
    }

    static void EncontrarEquipos(List<Equipo> equipos, Equipo local,
        Equipo visitante, out int indiceLocal, out int indiceVisitante)
    {
        indiceLocal = -1;
        indiceVisitante = -1;
        for (int i = 0; i < equipos.Count; i++)
        {
            if (equipos[i].Nombre == local.Nombre)
            {
                indiceLocal = i;
            }
            else if (equipos[i].Nombre == visitante.Nombre)
            {
                indiceVisitante = i;
            }
        }
    }
    static void ReiniciarTabla(List<Equipo> equipos)
    {
        foreach(Equipo e in equipos)
        {
            e.ReiniciarDatos();
        }
    }
    static void ProcesarPartidos(List<Partido> partidos, List<Equipo> equipos)
    {
        int indiceLocal, indiceVisitante;
        ReiniciarTabla(equipos);
        foreach (Partido partido in partidos)
        {
            Equipo local = partido.EquipoLocal;
            Equipo visitante = partido.EquipoVisitante;
            
            EncontrarEquipos(equipos, local, visitante,
                out indiceLocal, out indiceVisitante);

            if(indiceLocal != -1 && indiceVisitante != -1)
            {
                if(partido.PuntosLocal > partido.PuntosVisitante)
                {
                    equipos[indiceLocal].sumarPartidoGanado();
                    equipos[indiceVisitante].sumarPartidoPerdido();
                }
                else
                {
                    equipos[indiceVisitante].sumarPartidoGanado();
                    equipos[indiceLocal].sumarPartidoPerdido();
                }
                equipos[indiceLocal].sumarPuntosFavor(partido.PuntosLocal);
                equipos[indiceLocal].sumarPuntosContra
                    (partido.PuntosVisitante);
                
                equipos[indiceVisitante].sumarPuntosFavor
                    (partido.PuntosVisitante);
                equipos[indiceVisitante].sumarPuntosContra
                    (partido.PuntosLocal);
            }
            else
            {
                Console.WriteLine
                    ("Algún equipo no existe en la lista de equipos...");
            }
        }
    }
}

