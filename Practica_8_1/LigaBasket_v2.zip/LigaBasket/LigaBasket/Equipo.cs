﻿/*
 * Clase que gestiona la información de los equipos y sus puntuaciones
 */
class Equipo : IComparable<Equipo>
{
    private string nombre;
    private int partidosGanados;
    private int partidosPerdidos;
    private int puntosFavor;
    private int puntosContra;

    public Equipo(string nombre)
    {
        this.nombre = nombre;
        partidosGanados = 0;
        partidosPerdidos = 0;
        puntosFavor = 0;
        puntosContra = 0;
    }
    public void ReiniciarDatos()
    {
        partidosGanados = 0;
        partidosPerdidos = 0;
        puntosFavor = 0;
        puntosContra = 0;
    }
    public void MostrarEquipos(int y)
    {
        Console.SetCursorPosition(0, y);
        Console.Write(nombre);
        Console.SetCursorPosition(20, y);
        Console.Write(partidosGanados);
        Console.SetCursorPosition(25, y);
        Console.Write(partidosPerdidos);
        Console.SetCursorPosition(40, y);
        Console.Write(puntosFavor); 
        Console.SetCursorPosition(50, y);
        Console.Write(puntosContra);
    }

    public int CompareTo(Equipo e)
    {
        int comparacion = 0;
        comparacion = e.partidosGanados.CompareTo(this.partidosGanados);
        if(comparacion == 0)
        {
            comparacion = (e.puntosFavor - e.puntosContra).
                CompareTo(this.puntosFavor - this.puntosContra);
            if(comparacion == 0)
            {
                comparacion = e.puntosFavor.CompareTo(this.puntosFavor);
            }
        }
        return comparacion;
    }

    public void sumarPartidoGanado()
    {
        partidosGanados += 1;
    }
    public void sumarPartidoPerdido()
    {
        partidosPerdidos += 1;
    }
    public void sumarPuntosFavor(int puntos)
    {
        puntosFavor += puntos;
    }
    public void sumarPuntosContra(int puntos)
    {
        puntosContra += puntos;
    }

    public string Nombre
    {
        get { return nombre; } 
        set { nombre = value;}
    }
    public int PartidosGanados
    {
        get { return partidosGanados; }
        set { partidosGanados = value; }
    }
    public int PartidosPerdidos
    {
        get { return partidosPerdidos; }
        set { partidosPerdidos = value; }
    }
    public int PuntosFavor
    {
        get { return puntosFavor; }
        set { puntosFavor = value; }
    }
    public int PuntosContra
    {
        get { return puntosContra;}
        set { puntosContra = value; }
    }
}

