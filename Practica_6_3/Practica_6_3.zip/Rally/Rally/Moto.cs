﻿//Clase moto, clase hija de Vehículo
class Moto : Vehiculo
{
    private int cilindrada;

    public Moto(string marca, int velocidad, int cilindrada)
        : base(marca, velocidad)
    {
        this.cilindrada = cilindrada;
    }
}
