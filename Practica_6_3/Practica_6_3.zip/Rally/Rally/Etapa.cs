﻿//Clase Etapa con la interfaz IDibujable implementada
class Etapa : IDibujable
{
    private string ciudadOrigen;
    private string ciudadDestino;
    private int distancia;

    public Etapa(string ciudadOrigen, string ciudadDestino, int distancia)
    {
        this.distancia = distancia;
        this.ciudadDestino = ciudadDestino;
        this.ciudadOrigen = ciudadOrigen;
    }
    public void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Etapa: {0} - {1} ({2} km)",
            ciudadOrigen, ciudadDestino, distancia);
        Console.ResetColor();
    }

    public int Distancia
    {
        get { return distancia; }
        set { this.distancia = value; }
    }
}
