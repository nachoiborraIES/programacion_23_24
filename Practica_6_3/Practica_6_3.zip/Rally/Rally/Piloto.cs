﻿//Clase piloto con interfaz IDibujable
class Piloto : IDibujable
{
    private string nombre;
    private Vehiculo vehiculo;
    private int tiempoAcumulado;
    private int tiempoEtapa;

    public Piloto(string nombre, Vehiculo vehiculo)
    {
        this.nombre = nombre;
        this.vehiculo = vehiculo;
        tiempoAcumulado = 0;
        tiempoEtapa = 0;
    }
    public void Dibujar()
    {
        int horasEtapa, minutosEtapa, horasRally, minutosRally;
        horasEtapa = tiempoEtapa / 60;
        minutosEtapa = tiempoEtapa % 60;

        horasRally = tiempoAcumulado / 60;
        minutosRally = tiempoAcumulado % 60;
        Console.WriteLine("{0}: {1}h {2}m - {3}h {4}m", nombre,
            horasEtapa, minutosEtapa, horasRally, minutosRally);
    }

    public Vehiculo Vehiculo
    {
        get { return vehiculo; }
        set { vehiculo = value; }
    }

    public int TiempoAcumulado
    {
        get { return tiempoAcumulado; }
        set { tiempoAcumulado = value; }
    }

    public int TiempoEtapa
    {
        get { return tiempoEtapa; }
        set { tiempoEtapa = value; }
    }

}
