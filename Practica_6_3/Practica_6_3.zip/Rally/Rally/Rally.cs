﻿using static System.Net.Mime.MediaTypeNames;

//Clase del Rally
class Rally
{
    private Etapa[] etapas = new Etapa[10];
    private Piloto[] pilotos = new Piloto[10];
    private int contador;
    public Rally()
    {
        contador = 0;
    }

    public void Inicializar()
    {
        contador = 0;
        etapas[0] = new Etapa("Barcelona", "Marrakech", 2200);
        etapas[1] = new Etapa("París", "Estambul", 3000);
        etapas[2] = new Etapa("Ciudad de México", "Lima", 4500);
        etapas[3] = new Etapa("Sydney", "Perth", 3300);
        etapas[4] = new Etapa("Nueva York", "Los Angeles", 4500);
        etapas[5] = new Etapa("Tokio", "Sapporo", 800);
        etapas[6] = new Etapa("Roma", "Atenas", 1300);
        etapas[7] = new Etapa("Ciudad del Cabo", "El Cairo", 6000);
        etapas[8] = new Etapa("Buenos Aires", "Santiago", 1400);
        etapas[9] = new Etapa("Moscú", "Beijing", 5500);

        pilotos[0] = new Piloto("Malcolm Wilson", new Moto("Aprilia", 120, 
            250));
        pilotos[1] = new Piloto("Christian Loriaux", new Moto("Benelli", 160,
            240));
        pilotos[2] = new Piloto("Ari Vatanen", new Coche("Ford", 250, 1300, 
            3040));
        pilotos[3] = new Piloto("Cristina Gutierrez", new Moto("Harley", 140,
            220));
        pilotos[4] = new Piloto("Marta García", new Coche("Hyundai", 250, 
            1500, 2740));
        pilotos[5] = new Piloto("Emma Falcon", new Coche("BMW", 240, 1700, 
            2509));
        pilotos[6] = new Piloto("Alba Cano", new Coche("Cupra", 244, 1400, 
            2500));
        pilotos[7] = new Piloto("Natalia Gutierrez", new Coche("Seat", 260,
            1100, 2800));
        pilotos[8] = new Piloto("Tommi Makinen", new Moto("Ducati", 150, 
            260));
        pilotos[9] = new Piloto("Kiko Gadea", new Moto("Derbi", 170, 250));
    }

    public bool SiguienteEtapa()
    {
        bool siguiente;
        
        if (contador < etapas.Length)
        {
            AsignarTotales();
            siguiente = true;
            etapas[contador].Dibujar();
            contador++;
        }
        else
        {
            siguiente = false;
        }
        return siguiente;
    }

    public void AsignarTotales()
    {
        Random r = new Random();
        int velocidadMax;
        int minutos, velocidadMedia;

        for (int i = 0; i < pilotos.Length; i++)
        {
            velocidadMax = pilotos[i].Vehiculo.Velocidad;
            velocidadMedia = r.Next(velocidadMax * 80 / 100, velocidadMax + 1);
            minutos = etapas[contador].Distancia * 60 / velocidadMedia;

            pilotos[i].TiempoEtapa = minutos;
            pilotos[i].TiempoAcumulado += minutos;

        }
    }

    public void DibujarClasificacion(int y = 1)
    {
        Array.Sort(pilotos, (p1, p2) =>
            p1.TiempoAcumulado.CompareTo(p2.TiempoAcumulado));
        int x = Console.WindowWidth / 2;

        Console.SetCursorPosition(0, y);
        Console.WriteLine("COCHES");
        Console.SetCursorPosition(x, y);
        Console.WriteLine("MOTOS");

        ImprimirVehiculos(x, y);
    }

    public void ImprimirVehiculos(int x, int y)
    {
        int cont = y, num = 1;
        int cont2 = y, num2 = 1;
        for (int i = 0; i < pilotos.Length; i++)
        {
            if (pilotos[i].Vehiculo is Coche)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                cont++;
                Console.SetCursorPosition(0, cont);
                Console.Write(num + ". ");
                num++;
            }
            else if (pilotos[i].Vehiculo is Moto)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                cont2++;
                Console.SetCursorPosition(x, cont2);
                Console.Write(num2 + ". ");
                num2++;
            }
            pilotos[i].Dibujar();
            Console.WriteLine();
            Console.ResetColor();
        }
    }
}
