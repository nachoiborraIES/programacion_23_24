﻿/*Interfaz de IDibujable, para dibujar en pantalla los datos de los
 * pilotos y las etapas*/

interface IDibujable
{
    void Dibujar();
}
