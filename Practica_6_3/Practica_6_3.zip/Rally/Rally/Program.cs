﻿//Programa que simula las etapas de un rally
class Program
{
    static void Main(string[] args)
    {
        Rally rally = new Rally();
        ConsoleKeyInfo opcionUsuario;
        rally.Inicializar();
        
        do
        {
            rally.DibujarClasificacion();
            opcionUsuario = MostrarMenu();
            Console.Clear();
            switch (opcionUsuario.Key)
            {
                case ConsoleKey.S:
                    Console.Clear();
                    if (rally.SiguienteEtapa())
                    {
                        rally.DibujarClasificacion(1);
                    }
                    break;
                case ConsoleKey.R:
                    rally.Inicializar();
                    break;

                case ConsoleKey.Q:
                    break;
            }
        } while (opcionUsuario.Key != ConsoleKey.Q);
    }

    static ConsoleKeyInfo MostrarMenu()
    {

        Console.WriteLine("Elige una opción:");
        Console.WriteLine("Tecla 'S' para mostrar la siguiente etapa.");
        Console.WriteLine("Tecla 'R' para reiniciar los datos del Rally.");
        Console.WriteLine("Tecla 'Q' para salir.");
        return Console.ReadKey(true);
    }

}
