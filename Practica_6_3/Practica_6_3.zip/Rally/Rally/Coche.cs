﻿//Clase coche, clase hija de Vehículo
class Coche : Vehiculo
{
    private int potencia;
    private float peso;

    public Coche(string marca, int velocidad, int potencia, float peso)
        : base(marca, velocidad)
    {
        this.peso = peso;
        this.potencia = potencia;
    }
    public float Precio
    {
        get { return this.Precio; }
        set { this.Precio = value; }
    }
}
