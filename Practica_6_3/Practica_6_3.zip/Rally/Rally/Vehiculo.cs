﻿//Clase abstracta vehículo, clase padre de moto y coche
abstract class Vehiculo
{
    protected string marca;
    protected int velocidad;

    public Vehiculo(string marca, int velocidad)
    {
        this.marca = marca;
        this.velocidad = velocidad;
    }

    public string Marca
    {
        get { return this.marca; }
        set { marca = value; }
    }

    public int Velocidad
    {
        get { return velocidad; }
        set { velocidad = value; }
    }
}
