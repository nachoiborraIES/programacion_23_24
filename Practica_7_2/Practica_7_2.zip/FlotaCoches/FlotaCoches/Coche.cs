﻿// Clase Coche representa los coches de la flota.

class Coche
{
    private string matricula;
    private string marca;
    private string modelo;
    private List<Mantenimiento> mantenimientos;

    public Coche(string matricula, string marca, string modelo)
    {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        mantenimientos = new List<Mantenimiento> ();
    }
    public string Matricula
    {
        get { return matricula; } 
        set { matricula = value; }    
    }
    public string Marca
    {
        get { return marca; }
        set { marca = value; }
    }
    public string Modelo
    {
        get { return modelo; }
        set { modelo = value; }
    }
    public List<Mantenimiento> Mantenimientos
    {   
        get { return mantenimientos; }
        set { mantenimientos = value; }
    }
   
    public override string ToString()
    {
        return "Matrícula: " + matricula + ", Marca: " + marca + ", Modelo: "
        + modelo; 
    }
}