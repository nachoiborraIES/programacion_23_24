﻿/* Programa que gestiona una flota de coches y sus mantenimientos, en el que
 * se puede añadir mantenimientos, mostrar el vehículo más problemático,
 * listar los vehículos registrados en la flota y reemplazar vehículos borrando
 * alguno existente de la flota y añadiendo uno nuevo siempre que no se 
 * introduzca un número de matrícula que ya exista en la flota.
 */ 

using System.Collections;
enum Opciones { NUEVO=1,PROBLEMATICO,LISTAR,REEMPLAZAR,SALIR }
class FlotaCoches
{
    public static string matricula = "";
    static void Main(string[] args)
    {
        Dictionary<string, Coche> coches = InicializarCoches();
        Opciones opcionUsuario;
        
        do
        {
            opcionUsuario = MostrarMenu();

            switch (opcionUsuario)
            {
                case Opciones.NUEVO:
                    NuevoMantenimiento(coches);
                    break;

                case Opciones.PROBLEMATICO:
                    MostrarCocheMasProblematico(coches);
                    break;

                case Opciones.LISTAR:
                    ListadoDeCoches(coches);
                    break;

                case Opciones.REEMPLAZAR:
                    ReemplazarCoches(coches);
                    break;
                   
            }

            if (opcionUsuario != Opciones.SALIR)
            {
                Console.WriteLine("Pulsa Intro para continuar...");
                Console.ReadLine();
                Console.Clear();
            }
        }
        while (opcionUsuario != Opciones.SALIR);
        Console.WriteLine("¡Gracias, hasta pronto!");
    }

    static Opciones MostrarMenu()
    {
        Console.WriteLine("1. Nuevo mantenimiento");
        Console.WriteLine("2. Coche más problemático");
        Console.WriteLine("3. Listar coches");
        Console.WriteLine("4. Reemplazar coche");
        Console.WriteLine("5. Salir");
        Console.WriteLine("Elige una opción:");

        return (Opciones)Convert.ToInt32(Console.ReadLine());
    }

    private static Dictionary<string, Coche> InicializarCoches()
    {
        Dictionary<string,Coche> coches = new Dictionary<string, Coche>
        {
            { "4523-LMB", new Coche("4523-LMB", "SEAT", "LEON 1.5 TSI") },
            { "7200-KDN", new Coche("7200-KDN", "KIA", "RIO 1.0 TSI") },
            { "4132-KLW", new Coche("4132-KLW", "TOYOTA", "AURIS 1.8 TSI") },
            { "8299-GPZ", new Coche("8299-GPZ", "RENAULT", "SCENIC 2.0 TDI") },
            { "4238-BSX", new Coche("4238-BSX", "FORD", "FOCUS 1.8 TDI") }
        };
        return coches;
    }
    private static void NuevoMantenimiento(Dictionary<string, Coche> coches)
    {
        matricula = PedirMatricula();
        bool existe = BuscarCochePorMatricula(coches, matricula);
        if (existe)
        {
            coches[matricula].Mantenimientos.
               Add(CrearMantenimiento());
            Console.WriteLine("Mantenimiento añadido.");
        }
        else
        {
            Console.WriteLine("Coche no encontrado.");
        }
    }
    private static bool BuscarCochePorMatricula(Dictionary<string,Coche>coches,
        string matricula)
    {
        bool existe=false;
    
        if (coches.ContainsKey(matricula))
        {
            existe= true;
        }
  
        return existe;
    }
    private static Mantenimiento CrearMantenimiento() 
    {
        Mantenimiento nuevoMantenimiento;
        string fecha, descripcion;
        float precio;

        Console.WriteLine("Fecha:");
        fecha = Console.ReadLine();
        Console.WriteLine("Descripción:");
        descripcion = Console.ReadLine();
        Console.WriteLine("Precio:");
        precio = Convert.ToSingle(Console.ReadLine());

        nuevoMantenimiento = new Mantenimiento(fecha, descripcion, precio);

        return nuevoMantenimiento;
    }
    private static void ListadoDeCoches(Dictionary <string,Coche> coches)
    {
        IDictionaryEnumerator enumerador =coches.GetEnumerator();
        while (enumerador.MoveNext())
        {
            Console.WriteLine(enumerador.Value);
            Console.WriteLine();
        }
    }
    private static void MostrarCocheMasProblematico(Dictionary<string,
        Coche> coches)
    {
        Coche cocheMasProblematico = null;
        float max = 0, total = 0;

        foreach (Coche coche in coches.Values)
        {
            foreach (Mantenimiento mantenimiento in coche.Mantenimientos)
            {
                total += mantenimiento.Precio;
            }

            if (total > max)
            {
                max = total;
                cocheMasProblematico = coche;
            }
        }

        if (cocheMasProblematico != null)
        {
            Console.WriteLine("Información del coche más problemático:");
            Console.WriteLine(cocheMasProblematico);

            Console.WriteLine("\nMantenimientos:");
            foreach (Mantenimiento mantenimiento in 
                cocheMasProblematico.Mantenimientos)
            {
                Console.WriteLine(mantenimiento);
            }
            Console.WriteLine("\nPrecio total de mantenimientos: " + max);
        }
        else
        {
            Console.WriteLine("No hay ningún coche registrado.");
        }
    }
    private static void ReemplazarCoches(Dictionary <string,Coche> coches)
    {
        matricula = PedirMatricula();
        bool encontrado = BuscarCochePorMatricula(coches, matricula);
        if (encontrado)
        {
            coches.Remove(matricula);
            Console.WriteLine("Coche eliminado.");
            matricula = PedirMatricula();
            bool repetida = BuscarCochePorMatricula(coches, matricula);
            if (!repetida)
            {
                coches.Add(matricula, AñadirCocheNuevo());
                Console.WriteLine("Coche añadido.");
            }
            else
            {
                Console.WriteLine("Esa matricula ya esta registrada.");
            }
        }
        else
        {
            Console.WriteLine("Coche no encontrado.");
        }
    }
    private static Coche AñadirCocheNuevo()
    {
        Coche coche;
        string marca, modelo;
        
        Console.WriteLine("Marca:");
        marca = Console.ReadLine();
        Console.WriteLine("Modelo:");
        modelo = Console.ReadLine();

        coche = new Coche(matricula, marca, modelo);
   
        return coche;
    }
    private static string PedirMatricula()
    {
        string matricula;
      
        Console.WriteLine("Escribe la matricula:");
        matricula = Console.ReadLine();
        
        return matricula;
    }
}

