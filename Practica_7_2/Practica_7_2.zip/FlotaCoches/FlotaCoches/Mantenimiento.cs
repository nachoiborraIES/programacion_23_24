﻿//Clase Mantenimiento reprensenta los mantenimientos de los coches de la flota.

class Mantenimiento
{
    private string fecha;
    private string descripcion;
    private float precio;

    public Mantenimiento(string fecha, string descripcion, float precio)
    {
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public string Fecha
    { 
        get { return fecha; } 
        set { fecha = value; }
    }
    public string Descripcion
    { 
        get { return descripcion; }
        set { descripcion = value; }
    }
    public float Precio
    {
        get { return precio; }
        set { precio = value; }
    }
    public override string ToString()
    {
        return " Fecha: " + fecha + "\n Descripción: " + descripcion + 
            "\n Precio: " + precio;
    }
}