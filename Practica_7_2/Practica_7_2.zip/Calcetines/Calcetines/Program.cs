﻿/* Programa que lee por teclado una secuencia de números de calcetines
 * separados por espacios, si son el mismo número serán similares por lo que 
 * se agruparán en un conjunto. El programa indica cuántos modelos diferentes 
 * de calcetines hay y cuál es el número máximo de calcetines sueltos que hay
 * en un momento determinado.
 */

class Program
{
    static void Main(string[] args)
    {
        HashSet<int> modelos = new HashSet<int>();
        HashSet<int> sinEmparejar = new HashSet<int>();
        string[] calcetines;
        int maxSinEmparejar = 0;

        Console.WriteLine("Escribe una secuencia de números de calcetín" +
            " separados por espacios:");

        calcetines = Console.ReadLine().Split(' ');

        foreach (string calcetin in calcetines)
        {
            int numCalcetin = Int32.Parse(calcetin);

            if (sinEmparejar.Contains(numCalcetin))
            {
                sinEmparejar.Remove(numCalcetin);
            }
            else
            {
                modelos.Add(numCalcetin);
                sinEmparejar.Add(numCalcetin);
            }
            maxSinEmparejar = Math.Max(maxSinEmparejar, sinEmparejar.Count);
        }

        Console.WriteLine("Modelos diferentes de calcetines: " +
            modelos.Count);
        Console.WriteLine("Número máximo de calcetines sueltos: " +
            maxSinEmparejar);
    }
}
