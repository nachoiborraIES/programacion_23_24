﻿//Clase de los personajes Guerreros, hija de Personaje
class Guerrero : Personaje
{
    private string matEspada;

    public Guerrero(string matEspada, string nombre, int nivel):
        base(nombre, nivel)
    {
        MatEspada = matEspada;
    }

    public string MatEspada
    {
        get { return matEspada; }
        set { this.matEspada = value; }
    }

    public override string ToString()
    {
        return "Guerrero -> " + base.ToString() + 
            ", Material de la espada: " + matEspada;
    }

}
