﻿//Clase de los personajes magos, hija de Personaje
class Mago : Personaje
{
    private int poder;

    public Mago(int poder, string nombre, int nivel):
        base(nombre, nivel)
    {
        Poder = poder;
    }

    public int Poder
    {
        get { return poder; }
        set
        {
            if(value >=1 && value <= 10)
            {
                this.poder = value;
            }
            else
            {
                throw new Exception("El poder debe estar entre 1 y 10");
            }
        }
    }

    public override string ToString()
    {
        return "Mago -> " + base.ToString() + ", Poder mágico: " + poder;
    }
}
