﻿//Clase abstracta padre Personaje
abstract class Personaje
{
    private string nombre;
    private int nivel;

    public Personaje(string nombre, int nivel)
    {
        Nombre = nombre;
        Nivel = nivel;
    }

    public string Nombre
    {
        get { return nombre; }
        set { this.nombre = value; }
    }

    public int Nivel
    {
        get { return nivel; }
        set
        {
            if (value >= 0 && value <= 100)
            {
                this.nivel = value;
            }
            else
            {
                throw new Exception("El nivel debe de estar entre 0 y 100");
            }
        }
    }

    public override string ToString()
    {
        return "Nombre: " + nombre + ", Nivel: " + nivel;
    }
}
