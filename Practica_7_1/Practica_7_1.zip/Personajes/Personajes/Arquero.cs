﻿//Clase de personajes Arqueros, hija de Personaje
class Arquero : Personaje
{
    private int longArco;

    public Arquero(int longArco, string nombre, int nivel) : 
        base(nombre, nivel)
    {
        LongArco = longArco;
    }

    public int LongArco
    {
        get { return longArco; }
        set { this.longArco = value; }
    }

    public override string ToString()
    {
        return "Arquero -> " + base.ToString() + 
            ", Longitud del arco: " + LongArco;
    }
}
