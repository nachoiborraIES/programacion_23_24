﻿//Programa que crea una lista de personajes y el usuario puede hacer
//diferentes acciones, como eliminar u ordenarlos en base a ciertos criterios
class Program
{
    enum opciones { NUEVO = 1, NIVEL_VIDA, QUITAR, POCA_VIDA, MAS_VIDA, 
        SALIR }
    static void Main(string[] args)
    {
        opciones opcionUsuario;
        List<Personaje> personajes = new List<Personaje>();

        do
        {
            opcionUsuario = MostrarMenu();

            switch (opcionUsuario)
            {
                case opciones.NUEVO:
                    NuevoPersonaje(personajes);
                    MostrarPersonajes(personajes);
                    break;
                case opciones.NIVEL_VIDA:
                    OrdenarNivel(personajes);
                    break;
                case opciones.QUITAR:
                    QuitarPersonaje(personajes);
                    break;
                case opciones.POCA_VIDA:
                    PersonajesPocaVida(personajes);
                    break;
                case opciones.MAS_VIDA:
                    PersonajeMasVida(personajes);
                    break;
                case opciones.SALIR:
                    break;
            }

            if(opcionUsuario != opciones.SALIR)
            {
                Console.WriteLine("Pulsa cualquier tecla para continuar...");
                Console.ReadKey(true);
                Console.Clear();
            }
        } while (opcionUsuario != opciones.SALIR);

    }

    static opciones MostrarMenu()
    {
        Console.WriteLine("Elige una opción:");
        Console.WriteLine("1. Añadir nuevo personaje.");
        Console.WriteLine("2. Mostrar personajes por nivel de vida.");
        Console.WriteLine("3. Borrar personaje.");
        Console.WriteLine("4. Mostrar personajes con poca vida.");
        Console.WriteLine("5. Mostrar personaje con más vida.");
        Console.WriteLine("6. Salir.");
        return (opciones)Convert.ToInt32(Console.ReadLine());
    }

    static int MostrarOpciones()
    {
        Console.WriteLine("Elige un tipo de personaje:");
        Console.WriteLine("1. Arquero.");
        Console.WriteLine("2. Guerrero");
        Console.WriteLine("3. Mago.");

        return Convert.ToInt32(Console.ReadLine());
    }

    static void NuevoPersonaje(List<Personaje> p)
    {
        string nombre, matEspada;
        int nivel, longArco, poder;
        int tipo = MostrarOpciones();

        Console.WriteLine("Nombre:");
        nombre = Console.ReadLine();
        nivel = ComprobarNivel();

        if(tipo == 1)
        {
            Console.WriteLine("Longitud del arco: ");
            longArco = Convert.ToInt32(Console.ReadLine());
            p.Add(new Arquero(longArco, nombre, nivel));
        }
        else if(tipo == 2)
        {
            Console.WriteLine("Material de la espada:");
            matEspada = Console.ReadLine();
            p.Add(new Guerrero(matEspada, nombre, nivel));
        }
        else if(tipo == 3)
        {
            Console.WriteLine("Poder mágico:");
            poder = Convert.ToInt32(Console.ReadLine());
            p.Add(new Mago(poder, nombre, nivel));
        }

    }

    static void MostrarPersonajes(List<Personaje> personajes)
    {
        foreach(Personaje p in personajes)
        {
            Console.WriteLine(p);
        }
    }

    static int ComprobarNivel()
    {
        int n;
        bool valido = false;
        do
        {
            Console.WriteLine("Nivel de vida:");
            if (Int32.TryParse(Console.ReadLine(), out n) &&
                n >= 0 && n <= 100)
            {
                valido = true;
            }
        } while (!valido);

        return n;
    }

    
    static void OrdenarNivel(List<Personaje> p)
    {
        if (p.Count > 0)
        {
            p.Sort((p1, p2) => p2.Nivel.CompareTo(p1.Nivel));

            MostrarPersonajes(p);
        } 
        else
        {
            Console.WriteLine("No hay personajes en la lista.");
        }
    }

    static void QuitarPersonaje(List<Personaje> p)
    {
        if (p.Count > 0)
        {
            int cont = 0;
            bool encontrado = false;
            Console.WriteLine("Escribe el nombre del personaje que quieras" +
                " eliminar:");
            string nombre = Console.ReadLine();

            while (cont < p.Count)
            {
                if (p[cont].Nombre.Contains(nombre))
                {
                    p.RemoveAt(cont);
                    encontrado = true;
                }
                else
                {
                    cont++;
                }
            }

            if (encontrado)
                MostrarPersonajes(p);
            else
                Console.WriteLine("No se encuentra el personaje");
        }
        else
        {
            Console.WriteLine("No hay personajes.");
        }
    }

    static void PersonajesPocaVida(List<Personaje> p)
    {
        if (p.Count > 0)
        {
            int cont = 0;
            bool encontrado = false;

            while (cont < p.Count)
            {
                if (p[cont].Nivel < 10)
                {
                    Console.WriteLine(p[cont]);
                    encontrado = true;
                }
                cont++;
            }

            if (!encontrado)
            {
                Console.WriteLine("Todos los personajes tienen vida " +
                    "suficiente");
            }
        }
        else
        {
            Console.WriteLine("No hay personajes.");
        }
    }

    static void PersonajeMasVida(List<Personaje> p)
    {
        int cont = 1;
        
        if(p.Count > 0)
        {
            Personaje max = p[0];

            while(cont < p.Count)
            {
                if (p[cont].Nivel > max.Nivel)
                {
                    max = p[cont];
                }
                cont++;
            }

            Console.WriteLine(max);
        }
        else
        {
            Console.WriteLine("La lista está vacía.");
        }
    }

}
