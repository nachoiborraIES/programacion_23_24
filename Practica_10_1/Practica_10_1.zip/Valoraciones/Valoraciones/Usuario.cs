﻿using System;
using System.Collections.Generic;
using System.IO;

/*
 * Clase para almacenar los datos de los usuarios que hacen valoraciones
 */ 

class Usuario
{
    const string FICHERO = "valoraciones.txt";

    private string nombre;
    private string email;
    private DateTime fechaNac;
    private Valoracion valoracion;

    public Usuario(string nombre, string email,
        DateTime fechaNac, Valoracion valoracion)
    {
        this.nombre = nombre;
        this.email = email;
        this.fechaNac = fechaNac;
        this.valoracion = valoracion;
    }

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    public DateTime FechaNac
    {
        get { return fechaNac; }
        set { fechaNac = value; }
    }

    public Valoracion Valoracion
    {
        get { return valoracion; }
        set { valoracion = value; }
    }

    public string PasarFormato()
    {
        string resultado = Nombre + ";" + Email + ";"
            + FechaNac.ToString("dd/MM/yyyy") + ";" + (int)valoracion;
        return resultado;
    }

    public override string ToString()
    {
        return Nombre + ", " + Email + ", " +
            FechaNac.ToString("d") + ", " + Valoracion;
    }

    public static List<Usuario> CargarValoraciones()
    {
        List<Usuario> resultado = new List<Usuario>();
        if (File.Exists(FICHERO))
        {
            using (StreamReader fichero = new StreamReader(FICHERO))
            {
                string linea;
                while ((linea = fichero.ReadLine()) != null)
                {
                    string[] partes = linea.Split(';');

                    resultado.Add(new Usuario(partes[0], partes[1],
                        DateTime.ParseExact(partes[2], "dd/MM/yyyy", null),
                        (Valoracion)Convert.ToInt32(partes[3])));
                }
            }
        }
        return resultado;
    }

    public static void GuardarValoraciones(List<Usuario> valoraciones)
    {
        using (StreamWriter fichero = new StreamWriter(FICHERO))
        {
            foreach (Usuario u in valoraciones)
            {
                fichero.WriteLine(u.PasarFormato());
            }
        }
    }

}