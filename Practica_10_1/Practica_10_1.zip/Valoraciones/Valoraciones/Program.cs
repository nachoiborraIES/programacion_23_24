﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

/*
 * Programa principal para gestionar el listado de valoraciones
 * de los usuarios
 */

enum Valoracion
{
    MALA, REGULAR, BUENA, MUY_BUENA, EXCELENTE
}
class Program
{
    static void CalcularPorcentajes(List<Usuario> valoraciones)
    {
        double porcentaje;
        Console.WriteLine("Porcentajes de valoraciones:");
        foreach (Valoracion va in Enum.GetValues(typeof(Valoracion)))
        {
            porcentaje =
            valoraciones.Where
            (v => v.Valoracion == va).Count()
            * 100 / valoraciones.Count;
            Console.WriteLine("{0}% {1}", porcentaje, va);
        }     
        Console.WriteLine();
    }

    static void NombresExcelente(List<Usuario> valoraciones)
    {
        List<string> nombres = valoraciones.Where
            (v => v.Valoracion == Valoracion.EXCELENTE).Select
            (v => v.Nombre).ToList();
        string nombresUnidos = String.Join(", ", nombres);
        Console.WriteLine("Nombres de los usuarios (EXCELENTE)");
        Console.WriteLine(nombresUnidos);
        Console.WriteLine();
    }

    static void UsuariosOrdenados(List<Usuario> usuarios)
    {
        usuarios.Sort((u1, u2) => u2.FechaNac.CompareTo(u1.FechaNac));
        Console.WriteLine("Listado ordenado por edad");
        foreach(Usuario usario in usuarios)
        {
            Console.WriteLine(usario.Nombre);
        }
        Console.WriteLine();
    }

    static void DiferenciaDeDias(List<Usuario> usuarios)
    {
        TimeSpan diferencia =
            usuarios[0].FechaNac.Subtract
            (usuarios[usuarios.Count-1].FechaNac);
        Console.WriteLine("Diferencia de días entre el" +
            " usuario más joven y el más viejo: {0}", diferencia.Days);
    }

    static void AnyadirUsuario(List<Usuario> valoraciones)
    {
        string nombre, email;
        DateTime fechaNac = DateTime.Now;
        Valoracion valoracion = Valoracion.MALA; // Valor inicial arbitrario
        bool errores;
        do
        {
            errores = false;
            Console.WriteLine("Escribe el nombre o nada para terminar:");
            nombre = Console.ReadLine();
            if (nombre != "")
            {
                Console.WriteLine("Escribe el e-mail:");
                email = Console.ReadLine();
                Console.WriteLine("Escribe la fecha de naciento:");
                try
                {
                    fechaNac = DateTime.ParseExact
                        (Console.ReadLine(), "dd/MM/yyyy", null);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Fecha inválida");
                    errores = true;
                }
                if (!errores)
                {
                    try
                    {
                        Console.WriteLine("Escribe la valoracion");
                        Console.WriteLine("0 (Mala) - 4 (Excelente):");
                        valoracion = (Valoracion)
                            Convert.ToInt32(Console.ReadLine());
                        if (valoracion < Valoracion.MALA ||
                           valoracion > Valoracion.EXCELENTE)
                        {
                            throw new Exception();
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Valoración inválida");
                        errores = true;
                    }
                }
                if (!errores)
                    valoraciones.Add(new Usuario(nombre, email,
                        fechaNac, valoracion));
            }
        }
        while (nombre != "");
        Console.Clear();
    }

    static void Main(string[] args)
    {
        List<Usuario> valoraciones = Usuario.CargarValoraciones();
        AnyadirUsuario(valoraciones);
        Usuario.GuardarValoraciones(valoraciones);
        CalcularPorcentajes(valoraciones);
        NombresExcelente(valoraciones);
        UsuariosOrdenados(valoraciones);
        DiferenciaDeDias(valoraciones);
    }
}
