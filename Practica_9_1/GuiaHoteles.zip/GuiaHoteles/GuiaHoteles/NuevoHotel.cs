﻿/*Este es el código del formulario secundario que utilizamos para crear
 hoteles nuevos.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuiaHoteles
{
    public partial class NuevoHotel : Form
    {
        private Hotel hotelNuevo;

        public NuevoHotel()
        {
            InitializeComponent();
            hotelNuevo = null;
        }
        public Hotel HotelNuevo 
        {
            get { return hotelNuevo; } 
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(txtNombre.Text != "" && cBoxProvincia.Text != "" && 
                txtPrecio.Text != "" && cBoxEstrellas.Text != "")
            {
                string nombre = txtNombre.Text;
                string provincia = cBoxProvincia.Text;
                float precio = Convert.ToSingle(txtPrecio.Text);
                int estrellas = Convert.ToInt32(cBoxEstrellas.Text.Length);
                hotelNuevo = new Hotel(nombre, provincia, precio, estrellas);
                Close();
            }
            else
            {
                MessageBox.Show("Todos los campos deben contener información");
            }
        }
    }
}
