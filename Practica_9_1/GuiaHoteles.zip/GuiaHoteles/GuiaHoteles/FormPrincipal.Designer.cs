﻿namespace GuiaHoteles
{
    partial class FormPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            menuStripHoteles = new ToolStripMenuItem();
            menuStripHotelesNuevo = new ToolStripMenuItem();
            menuStripHotelesSalir = new ToolStripMenuItem();
            lblTitulo = new Label();
            lstHoteles = new ListBox();
            lblProvincia = new Label();
            lblPrecio = new Label();
            lblEstrellas = new Label();
            txtPrecio = new TextBox();
            cBoxProvincia = new ComboBox();
            cBoxEstrellas = new ComboBox();
            lblEUR = new Label();
            btnAplicar = new Button();
            btnBorrar = new Button();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuStripHoteles });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(484, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuStripHoteles
            // 
            menuStripHoteles.DropDownItems.AddRange(new ToolStripItem[] { menuStripHotelesNuevo, menuStripHotelesSalir });
            menuStripHoteles.Name = "menuStripHoteles";
            menuStripHoteles.Size = new Size(59, 20);
            menuStripHoteles.Text = "Hoteles";
            // 
            // menuStripHotelesNuevo
            // 
            menuStripHotelesNuevo.Name = "menuStripHotelesNuevo";
            menuStripHotelesNuevo.Size = new Size(109, 22);
            menuStripHotelesNuevo.Text = "Nuevo";
            menuStripHotelesNuevo.Click += menuStripHotelesNuevo_Click;
            // 
            // menuStripHotelesSalir
            // 
            menuStripHotelesSalir.Name = "menuStripHotelesSalir";
            menuStripHotelesSalir.Size = new Size(109, 22);
            menuStripHotelesSalir.Text = "Salir";
            menuStripHotelesSalir.Click += menuStripHotelesSalir_Click;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblTitulo.ForeColor = SystemColors.ControlLightLight;
            lblTitulo.Location = new Point(12, 40);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(164, 30);
            lblTitulo.TabIndex = 1;
            lblTitulo.Text = "Guía de hoteles";
            // 
            // lstHoteles
            // 
            lstHoteles.FormattingEnabled = true;
            lstHoteles.ItemHeight = 15;
            lstHoteles.Location = new Point(12, 84);
            lstHoteles.Name = "lstHoteles";
            lstHoteles.Size = new Size(460, 184);
            lstHoteles.TabIndex = 2;
            // 
            // lblProvincia
            // 
            lblProvincia.AutoSize = true;
            lblProvincia.ForeColor = SystemColors.ControlLightLight;
            lblProvincia.Location = new Point(78, 294);
            lblProvincia.Name = "lblProvincia";
            lblProvincia.Size = new Size(59, 15);
            lblProvincia.TabIndex = 3;
            lblProvincia.Text = "Provincia:";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.ForeColor = SystemColors.ControlLightLight;
            lblPrecio.Location = new Point(78, 341);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(83, 15);
            lblPrecio.TabIndex = 4;
            lblPrecio.Text = "Precio/Noche:";
            // 
            // lblEstrellas
            // 
            lblEstrellas.AutoSize = true;
            lblEstrellas.ForeColor = SystemColors.ControlLightLight;
            lblEstrellas.Location = new Point(78, 389);
            lblEstrellas.Name = "lblEstrellas";
            lblEstrellas.Size = new Size(52, 15);
            lblEstrellas.TabIndex = 5;
            lblEstrellas.Text = "Estrellas:";
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(167, 338);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(178, 23);
            txtPrecio.TabIndex = 6;
            // 
            // cBoxProvincia
            // 
            cBoxProvincia.DropDownStyle = ComboBoxStyle.DropDownList;
            cBoxProvincia.FormattingEnabled = true;
            cBoxProvincia.Items.AddRange(new object[] { "Álava", "Albacete", "Alicante", "Almería", "Asturias", "Ávila", "Badajoz", "Barcelona", "Burgos", "Cáceres", "Cádiz", "Cantabria", "Castellón", "Ciudad Real", "Córdoba", "La Coruña", "Cuenca", "Gerona", "Granada", "Guadalajara", "Guipúzcoa", "Huelva", "Huesca", "Islas Baleares", "Jaén", "León", "Lérida", "Lugo", "Madrid", "Málaga", "Murcia", "Navarra", "Orense", "Palencia", "Las Palmas", "Pontevedra", "La Rioja", "Salamanca", "Segovia", "Sevilla", "Soria", "Tarragona", "Santa Cruz de Tenerife", "Teruel", "Toledo", "Valencia", "Valladolid", "Vizcaya", "Zamora", "Zaragoza" });
            cBoxProvincia.Location = new Point(167, 291);
            cBoxProvincia.Name = "cBoxProvincia";
            cBoxProvincia.Size = new Size(227, 23);
            cBoxProvincia.TabIndex = 7;
            // 
            // cBoxEstrellas
            // 
            cBoxEstrellas.DropDownStyle = ComboBoxStyle.DropDownList;
            cBoxEstrellas.FormattingEnabled = true;
            cBoxEstrellas.Items.AddRange(new object[] { "*", "**", "***", "****", "*****" });
            cBoxEstrellas.Location = new Point(167, 386);
            cBoxEstrellas.Name = "cBoxEstrellas";
            cBoxEstrellas.Size = new Size(227, 23);
            cBoxEstrellas.TabIndex = 8;
            // 
            // lblEUR
            // 
            lblEUR.AutoSize = true;
            lblEUR.ForeColor = SystemColors.ControlLightLight;
            lblEUR.Location = new Point(351, 341);
            lblEUR.Name = "lblEUR";
            lblEUR.Size = new Size(28, 15);
            lblEUR.TabIndex = 9;
            lblEUR.Text = "EUR";
            // 
            // btnAplicar
            // 
            btnAplicar.Location = new Point(127, 426);
            btnAplicar.Name = "btnAplicar";
            btnAplicar.Size = new Size(114, 23);
            btnAplicar.TabIndex = 10;
            btnAplicar.Text = "Aplicar Filtros";
            btnAplicar.UseVisualStyleBackColor = true;
            btnAplicar.Click += btnAplicar_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(263, 426);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(114, 23);
            btnBorrar.TabIndex = 11;
            btnBorrar.Text = "Borrar Filtros";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // FormPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(484, 461);
            Controls.Add(btnBorrar);
            Controls.Add(btnAplicar);
            Controls.Add(lblEUR);
            Controls.Add(cBoxEstrellas);
            Controls.Add(cBoxProvincia);
            Controls.Add(txtPrecio);
            Controls.Add(lblEstrellas);
            Controls.Add(lblPrecio);
            Controls.Add(lblProvincia);
            Controls.Add(lstHoteles);
            Controls.Add(lblTitulo);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MainMenuStrip = menuStrip1;
            MaximizeBox = false;
            Name = "FormPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Guía Hoteles";
            FormClosing += FormPrincipal_FormClosing;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuStripHoteles;
        private ToolStripMenuItem menuStripHotelesNuevo;
        private ToolStripMenuItem menuStripHotelesSalir;
        private Label lblTitulo;
        private ListBox lstHoteles;
        private Label lblProvincia;
        private Label lblPrecio;
        private Label lblEstrellas;
        private TextBox txtPrecio;
        private ComboBox cBoxProvincia;
        private ComboBox cBoxEstrellas;
        private Label lblEUR;
        private Button btnAplicar;
        private Button btnBorrar;
    }
}