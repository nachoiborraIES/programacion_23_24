﻿namespace GuiaHoteles
{
    partial class NuevoHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombre = new Label();
            lblProvincia = new Label();
            lblPrecio = new Label();
            lblEstrellas = new Label();
            txtNombre = new TextBox();
            cBoxProvincia = new ComboBox();
            txtPrecio = new TextBox();
            lblEUR = new Label();
            cBoxEstrellas = new ComboBox();
            btnAdd = new Button();
            SuspendLayout();
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.ForeColor = SystemColors.ControlLightLight;
            lblNombre.Location = new Point(25, 23);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(54, 15);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre:";
            // 
            // lblProvincia
            // 
            lblProvincia.AutoSize = true;
            lblProvincia.ForeColor = SystemColors.ControlLightLight;
            lblProvincia.Location = new Point(26, 97);
            lblProvincia.Name = "lblProvincia";
            lblProvincia.Size = new Size(59, 15);
            lblProvincia.TabIndex = 1;
            lblProvincia.Text = "Provincia:";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.ForeColor = SystemColors.ControlLightLight;
            lblPrecio.Location = new Point(26, 169);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(83, 15);
            lblPrecio.TabIndex = 2;
            lblPrecio.Text = "Precio/Noche:";
            // 
            // lblEstrellas
            // 
            lblEstrellas.AutoSize = true;
            lblEstrellas.ForeColor = SystemColors.ControlLightLight;
            lblEstrellas.Location = new Point(26, 242);
            lblEstrellas.Name = "lblEstrellas";
            lblEstrellas.Size = new Size(52, 15);
            lblEstrellas.TabIndex = 3;
            lblEstrellas.Text = "Estrellas:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(26, 51);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(334, 23);
            txtNombre.TabIndex = 4;
            // 
            // cBoxProvincia
            // 
            cBoxProvincia.DropDownStyle = ComboBoxStyle.DropDownList;
            cBoxProvincia.FormattingEnabled = true;
            cBoxProvincia.Items.AddRange(new object[] { "Álava", "Albacete", "Alicante", "Almería", "Asturias", "Ávila", "Badajoz", "Barcelona", "Burgos", "Cáceres", "Cádiz", "Cantabria", "Castellón", "Ciudad Real", "Córdoba", "La Coruña", "Cuenca", "Gerona", "Granada", "Guadalajara", "Guipúzcoa", "Huelva", "Huesca", "Islas Baleares", "Jaén", "León", "Lérida", "Lugo", "Madrid", "Málaga", "Murcia", "Navarra", "Orense", "Palencia", "Las Palmas", "Pontevedra", "La Rioja", "Salamanca", "Segovia", "Sevilla", "Soria", "Tarragona", "Santa Cruz de Tenerife", "Teruel", "Toledo", "Valencia", "Valladolid", "Vizcaya", "Zamora", "Zaragoza" });
            cBoxProvincia.Location = new Point(25, 125);
            cBoxProvincia.Name = "cBoxProvincia";
            cBoxProvincia.Size = new Size(335, 23);
            cBoxProvincia.TabIndex = 5;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(26, 197);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(300, 23);
            txtPrecio.TabIndex = 6;
            // 
            // lblEUR
            // 
            lblEUR.AutoSize = true;
            lblEUR.ForeColor = SystemColors.ControlLightLight;
            lblEUR.Location = new Point(332, 200);
            lblEUR.Name = "lblEUR";
            lblEUR.Size = new Size(28, 15);
            lblEUR.TabIndex = 7;
            lblEUR.Text = "EUR";
            // 
            // cBoxEstrellas
            // 
            cBoxEstrellas.DropDownStyle = ComboBoxStyle.DropDownList;
            cBoxEstrellas.FormattingEnabled = true;
            cBoxEstrellas.Items.AddRange(new object[] { "*", "**", "***", "****", "*****" });
            cBoxEstrellas.Location = new Point(26, 272);
            cBoxEstrellas.Name = "cBoxEstrellas";
            cBoxEstrellas.Size = new Size(335, 23);
            cBoxEstrellas.TabIndex = 8;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(150, 317);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "Añadir";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // NuevoHotel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(384, 361);
            Controls.Add(btnAdd);
            Controls.Add(cBoxEstrellas);
            Controls.Add(lblEUR);
            Controls.Add(txtPrecio);
            Controls.Add(cBoxProvincia);
            Controls.Add(txtNombre);
            Controls.Add(lblEstrellas);
            Controls.Add(lblPrecio);
            Controls.Add(lblProvincia);
            Controls.Add(lblNombre);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "NuevoHotel";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Nuevo Hotel";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombre;
        private Label lblProvincia;
        private Label lblPrecio;
        private Label lblEstrellas;
        private TextBox txtNombre;
        private ComboBox cBoxProvincia;
        private TextBox txtPrecio;
        private Label lblEUR;
        private ComboBox cBoxEstrellas;
        private Button btnAdd;
    }
}