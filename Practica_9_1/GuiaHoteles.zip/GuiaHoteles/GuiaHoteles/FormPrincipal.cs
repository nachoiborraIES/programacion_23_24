/*Este es el c�digo del formulario principal en el que ejecutamos todas las
 funciones de los controles.*/

using System.Text.Json;

namespace GuiaHoteles
{
    public partial class FormPrincipal : Form
    {
        List<Hotel> hoteles;

        public FormPrincipal()
        {
            InitializeComponent();
            hoteles = Hotel.Deserializar();
            EscribirLista(hoteles);
        }

        private void EscribirLista(List<Hotel> hoteles)
        {
            hoteles.Sort((h1, h2) => h1.Nombre.CompareTo(h2.Nombre));
            lstHoteles.Items.Clear();
            for (int i = 0; i < hoteles.Count; i++)
            {
                lstHoteles.Items.Add(hoteles[i]);
            }
        }
        private void btnAplicar_Click(object sender, EventArgs e)
        {
            List<Hotel> hotelesFiltrados = hoteles;
            if (cBoxProvincia.Text != "")
            {
                string provincia = cBoxProvincia.Text;
                hotelesFiltrados = hotelesFiltrados.Where(h => (h.Provincia ==
                    provincia)).ToList();
            }
            if (txtPrecio.Text != "")
            {
                float precio = Convert.ToSingle(txtPrecio.Text);
                hotelesFiltrados = hotelesFiltrados.Where(h => (h.Precio <=
                    precio)).ToList();
            }
            if (cBoxEstrellas.Text != "")
            {
                int estrellas = cBoxEstrellas.Text.Length;
                hotelesFiltrados = hotelesFiltrados.Where(h => (h.Estrellas ==
                    estrellas)).ToList();
            }
            EscribirLista(hotelesFiltrados);
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            cBoxProvincia.Text = null;
            txtPrecio.Text = "";
            cBoxEstrellas.Text = null;
            EscribirLista(hoteles);
        }

        private void menuStripHotelesSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void menuStripHotelesNuevo_Click(object sender, EventArgs e)
        {
            NuevoHotel nuevoHotel = new NuevoHotel();
            nuevoHotel.ShowDialog();
            if (nuevoHotel.HotelNuevo != null)
            {
                hoteles.Add(nuevoHotel.HotelNuevo);
                cBoxProvincia.Text = null;
                txtPrecio.Text = "";
                cBoxEstrellas.Text = null;
                EscribirLista(hoteles);
            }
        }

        private void FormPrincipal_FormClosing(object sender,
            FormClosingEventArgs e)
        {
            Hotel.Serializar(hoteles);
        }
    }
}