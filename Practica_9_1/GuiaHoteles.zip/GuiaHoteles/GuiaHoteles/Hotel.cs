﻿/*La clase Hotel contiene toda la información respecto a los hoteles de
 nuestra aplicación.*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GuiaHoteles
{
    public class Hotel
    {
        const string FICHERO = "hoteles.json";

        private string nombre;
        private string provincia;
        private float precio;
        private int estrellas;

        public Hotel(string nombre, string provincia, float precio, 
            int estrellas)
        {
            this.nombre = nombre;
            this.provincia = provincia;
            this.precio = precio;
            this.estrellas = estrellas;
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Provincia
        {
            get { return provincia; }
            set { provincia = value; }
        }
        public float Precio
        {
            get { return precio; }
            set { precio = value; }
        }
        public int Estrellas
        {
            get { return estrellas; }
            set { estrellas = value; }
        }
        public override string ToString()
        {
            string nEstrellas = "";
            for(int i = 0; i < estrellas; i++)
            {
                nEstrellas += "*";
            }
            return "Hotel " + nombre + "(" + provincia + ", " + precio + 
                " eur/noche, " + nEstrellas + ")";
        }

        public static void Serializar(List<Hotel> hoteles)
        {
            var opciones = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(hoteles, opciones);
            File.WriteAllText(FICHERO, json);
        }

        public static  List<Hotel> Deserializar()
        {
            List<Hotel> hoteles = new List<Hotel>();
            if (File.Exists(FICHERO))
            {
                string json = File.ReadAllText(FICHERO);
                hoteles = JsonSerializer.Deserialize<List<Hotel>>(json);
            }
            return hoteles;
        }
    }
}
