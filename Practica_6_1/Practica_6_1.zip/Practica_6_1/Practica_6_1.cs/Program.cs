﻿
/* 
* Programa que gestiona un array de habitaciones de hotel. Permite añadir
* habitaciones, buscarlas y filtrar por precio. Ahora funciona con clases en
* vez de structs
*/

using System;

class Practica4
{
    enum opciones { SALIR, NUEVA, LISTADO, BUSCAR, FILTRAR, ORDENAR, AVANZADO }



    static void Main()
    {
        Habitacion[] habitaciones = new global::Habitacion[100];
        int cantidad = 0, numHabitacion;
        opciones opcionUsuario;
        float filtroPrecio;

        do
        {
            opcionUsuario = MostrarMenu();

            switch (opcionUsuario)
            {
                case opciones.NUEVA:
                    int retorno = NuevaHabitacion(habitaciones, ref cantidad);
                    if (retorno == 0)
                    {
                        Console.WriteLine("Habitación añadida correctamente.");
                    }
                    else if (retorno == 1)
                    {
                        Console.WriteLine("Habitación ya existente.");
                    }
                    else
                    {
                        Console.WriteLine("No caben más habitaciones.");
                    }
                    break;

                case opciones.LISTADO:
                    ListarHabitaciones(habitaciones, cantidad);
                    break;

                case opciones.BUSCAR:
                    Console.WriteLine("Número de la habitación a buscar:");
                    numHabitacion = Convert.ToInt32(Console.ReadLine());
                    BuscarHabitacion(habitaciones, cantidad, numHabitacion);
                    break;

                case opciones.FILTRAR:
                    Console.WriteLine("Dime un precio máximo:");
                    filtroPrecio = Convert.ToSingle(Console.ReadLine());
                    FiltrarHabitaciones(habitaciones, cantidad, filtroPrecio);
                    break;
            }

            if (opcionUsuario != opciones.SALIR)
            {
                Console.WriteLine("Pulsa Intro para continuar...");
                Console.ReadLine();
                Console.Clear();
            }
        }
        while (opcionUsuario != opciones.SALIR);
    }

    static opciones MostrarMenu()
    {
        Console.WriteLine("1. Añadir habitación");
        Console.WriteLine("2. Ver listado de habitaciones");
        Console.WriteLine("3. Buscar habitaciones");
        Console.WriteLine("4. Filtrar habitaciones");
        Console.WriteLine("0. Salir del programa");
        Console.WriteLine("Elige una opción:");

        return (opciones)Convert.ToInt32(Console.ReadLine());
    }

    static int NuevaHabitacion(Habitacion[] habitaciones, ref int cantidad)
    {
        int numHabitacion;
        int posicion;
        int retorno;

        if (cantidad < habitaciones.Length)
        {
            habitaciones[cantidad] = new Habitacion();

            Console.WriteLine("Número de habitación:");
            numHabitacion = Convert.ToInt32(Console.ReadLine());
            habitaciones[cantidad].Numero = numHabitacion;

            posicion = BuscarRepetida(habitaciones, cantidad, 
                habitaciones[cantidad].Numero);
            if (posicion < 0)
            {
                AsignarValorHabitacion(habitaciones, cantidad, numHabitacion);
                cantidad++;
                retorno = 0;
            }
            else
            {
                retorno = 1;
            }

        }
        else
        {
            retorno = 2;
        }
        return retorno;
    }

    static int BuscarRepetida(Habitacion[] habitaciones, int cantidad,
        int numHabitacion)
    {
        int repetida = -1;

        for (int i = 0; i < cantidad; i++)
        {
            if (numHabitacion == habitaciones[i].Numero)
            {
                repetida = i;
            }
        }

        return repetida;
    }

    static void AsignarValorHabitacion(Habitacion[] habitaciones, int cantidad,
        int numHabitacion)
    {
        Console.WriteLine("Precio por noche:");
        habitaciones[cantidad].Precio =
        Convert.ToSingle(Console.ReadLine());

        ComprobarHuespedes(habitaciones, cantidad);

        Console.WriteLine("Descripción de la habitación:");
        habitaciones[cantidad].Descripcion = Console.ReadLine();
    }

    static void ComprobarHuespedes(Habitacion[] habitaciones, int cantidad)
    {
        do
        {
            try
            {
                Console.WriteLine("Max. huéspedes:");
                habitaciones[cantidad].Huespedes
                    = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception)
            {
                Console.WriteLine("Cantidad no válida");
            }
        }
        while (habitaciones[cantidad].Huespedes > 5
            || habitaciones[cantidad].Huespedes < 1);
    }

    static void ListarHabitaciones(Habitacion[] habitaciones, int cantidad)
    {

        OrdenarArray(habitaciones, cantidad);

        if (cantidad > 0)
        {
            for (int i = 0; i < cantidad; i++)
            {
                habitaciones[i].MostrarInf();
            }
        }
        else
        {
            Console.WriteLine("No hay habitaciones almacenadas");
        }
    }

    static Habitacion[] OrdenarArray(Habitacion[] habitaciones, int cantidad)
    {
        for (int i = 0; i < cantidad; i++)
        {
            for (int j = 0; j < cantidad - i - 1; j++)
            {
                if (habitaciones[j].Numero > habitaciones[j + 1].Numero)
                {
                    Habitacion auxiliar = habitaciones[j];
                    habitaciones[j] = habitaciones[j + 1];
                    habitaciones[j + 1] = auxiliar;
                }
            }
        }


        return habitaciones;
    }


    static void BuscarHabitacion(Habitacion[] habitaciones, int cantidad,
        int numHabitacion)
    {
        if (cantidad > 0)
        {
            int posicion;
            posicion = BuscarRepetida(habitaciones, cantidad, numHabitacion);
            if (posicion >= 0)
            {
                habitaciones[posicion].MostrarInf();
            }
            else
            {
                Console.WriteLine("Habitacion no encontrada");
            }
        }
        else
        {
            Console.WriteLine("No hay habitaciones almacenadas");
        }
    }

    static void FiltrarHabitaciones(Habitacion[] habitaciones, int cantidad,
        float filtroPrecio)
    {
        bool encontrado = false;
        if (cantidad > 0)
        {
            for (int i = 0; i < cantidad; i++)
            {
                if (filtroPrecio >= habitaciones[i].Precio)
                {
                    habitaciones[i].MostrarInf();
                    encontrado = true;
                }
            }
            if (!encontrado)
            {
                Console.WriteLine("No se encontraron coincidencias");
            }
        }
        else
        {
            Console.WriteLine("No hay habitaciones almacenadas");
        }
    }

}


