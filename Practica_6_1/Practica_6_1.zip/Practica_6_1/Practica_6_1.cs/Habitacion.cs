﻿
//Codigo de clase Habitacion con sus getter y setters

using System;

class Habitacion
{
    private int huespedes;
    private int numero;
    private float precio;
    private string descripcion;

    public Habitacion()
    {

    }

    public Habitacion(int numero , string descripcion ,int huespedes , 
        float precio)
    {
        this.Huespedes = huespedes;
        this.Numero = numero;
        this.Precio = precio;
        this.descripcion = descripcion;
    }

    public int Huespedes
    {
        get
        {
            return huespedes;
        }

        set
        {
            if(value >= 1 && value <= 5)
            {
                this.huespedes = value;
            }
            else if (value > 5)
            {
                this.huespedes = 5;
            }
            else
            {
                this.huespedes = 1;
            }
        }
    }

    public  int Numero
    {
        get
        {
            return numero;
        }

        set
        {
            if(value >= 1 && value <= 100)
            {
                this.numero = value;

            }else if (value > 100)
            {
                this.numero = 100;
            }
            else
            {
                this.numero = 1;
            }
        }
    }

    public float Precio
    {
        get
        {
            return precio;
        }


        set
        {
            if (value >= 0)
            {
                this.precio = value;
            }
            else
            {
                this.precio = 0;
            }
        }
    }

    public string Descripcion
    {
        get
        {
            return descripcion;
        }

        set
        {
            this.descripcion = value;
        }
    }


    public void MostrarInf()
    {
        Console.WriteLine("Habitacion {0} , {1} , {2} huespedes , {3}" +
            " euros/noche" , numero , descripcion , huespedes , precio);
    }
}

